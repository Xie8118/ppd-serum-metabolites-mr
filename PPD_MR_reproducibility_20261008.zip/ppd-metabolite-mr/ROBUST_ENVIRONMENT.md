# Robust MR software environment

Current supporting environment, inspected 6 October 2026: R 4.3.3, MendelianRandomization 0.10.0 (mr_divw), and mr.raps 0.2. These are the versions selected for subsequent reproducibility checks, not independently verified historical runtime versions for the first submission. Original estimates have not been refitted or replaced.

In both inspected installations, mr.raps defaults to over.dispersion=FALSE, loss.function="l2", diagnosis=FALSE, and se.method="sandwich". The default B is 1000 but bootstrap SEs are not selected by default. The historical candidate call specified only the four association vectors; its exact identity with the first-submission implementation remains unverified.

The recovered candidate D-IVW call explicitly sets over.dispersion=TRUE, alpha=0.05 and diagnostics=FALSE. Package inspection and source recovery are not a numerical reproduction test.

Run Rscript R/04_check_robust_environment.R to verify the selected environment without running MR.
