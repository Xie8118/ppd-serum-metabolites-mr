# Full-screen retained instruments

Run from the repository root:

```sh
python instruments/reconstruct_full_screen.py --repo-root . --output instruments/generated
```

Requires Python, NumPy, pandas, SciPy and openpyxl. Final paired exposure-effect alleles are nucleotide strings. The script compares exposure and outcome effect-allele labels, aligns outcome effects, applies the recorded filtering rules, and independently verifies all 485 final primary estimates. It provides 9,728 retained SNP–metabolite records and 880 excluded records. LD clumping is not repeated, and full historical strand/frequency harmonization logs are unavailable. The generated records are reconstructed, rather than contemporaneously saved analysis logs.

Final primary estimates are in data/primary_results.tsv and sensitivity estimates are in data/sensitivity_results.tsv. The paired associations are in data/paired_instruments.csv.
