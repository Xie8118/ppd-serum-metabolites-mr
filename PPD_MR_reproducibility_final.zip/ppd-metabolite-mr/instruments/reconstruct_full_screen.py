#!/usr/bin/env python3
"""Reconstruct retained records and verify final primary MR estimates.

This is a new verification implementation, not a recovered historical driver.
This label-based reconstruction does not establish complete strand/frequency harmonization.
See README.md.
"""
import argparse
import hashlib
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.stats import chi2, norm


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo-root', type=Path, default=Path('.'))
    ap.add_argument('--output', type=Path, default=Path('instruments/generated'))
    args = ap.parse_args()
    root, out = args.repo_root.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    paired_path = root / 'data/paired_instruments.csv'
    primary_path = root / 'data/primary_results.tsv'
    sensitivity_path = root / 'data/sensitivity_results.tsv'
    d = pd.read_csv(paired_path, dtype={'SNP':str, 'traits':str,
        'INC_ALLELE.x':str, 'DEC_ALLELE.x':str,
        'INC_ALLELE.y':str, 'DEC_ALLELE.y':str}, float_precision='round_trip')
    source_cols = list(d.columns)
    d.insert(0, 'source_row_1based', np.arange(1, len(d)+1))
    primary = pd.read_csv(primary_path, sep='\t').set_index('metabolite_id')
    sensitivity = pd.read_csv(sensitivity_path, sep='\t').set_index('Exp')
    assert len(d)==10608 and d.traits.nunique()==485
    assert set(d.traits)==set(sensitivity.index)
    assert set(primary.index[primary.nIV.notna()])==set(sensitivity.index)
    processed, summaries = [], []
    for mid, group in d.groupby('traits', sort=True):
        g = group.copy()
        labels_same = g['INC_ALLELE.x'].str.upper().eq(g['INC_ALLELE.y'].str.upper())
        has_match = bool(labels_same.any())
        g['metabolite'] = primary.at[mid, 'metabolite']
        g['outcome_beta_aligned'] = g['BETA.y'] * np.where(labels_same,1,-1)
        g['label_action'] = np.where(labels_same,'same_label','opposite_label_sign_flip')
        allele_ok = np.ones(len(g), dtype=bool)
        for c in ['INC_ALLELE.x','DEC_ALLELE.x','INC_ALLELE.y','DEC_ALLELE.y']:
            allele_ok &= g[c].str.upper().isin(['A','C','G','T']).to_numpy()
        g['allele_label_status'] = np.where(allele_ok,'canonical_source_labels_not_full_strand_audit','noncanonical_source_label_requires_confirmation')
        g['record_status'] = 'retained'
        g['exclusion_stage'] = ''
        g['outcome_P_filter_n'] = np.nan
        g['cook_filter_n'] = np.nan
        g['cook_distance'] = np.nan
        g['cook_cutoff'] = np.nan
        g['marginal_F'] = (g['BETA.x']/g['SE.x'])**2
        g['approximate_R2'] = g.marginal_F/(g.marginal_F+g['N.x']-2)
        mean_source_N = float(g['N.x'].mean())
        g['F_original_mean_N_adjustment'] = g.marginal_F*(mean_source_N-2)/mean_source_N

        def exclude(mask, reason):
            ix = g.index[(g.record_status=='retained') & mask]
            g.loc[ix,'record_status'] = 'excluded'
            g.loc[ix,'exclusion_stage'] = reason

        exclude((g['CHR.x']==6)&g['POS.x'].between(28477797,33448354), 'HLA_GRCh37_28477797_33448354')
        exclude(g['BETA.x'].isna()|g.outcome_beta_aligned.isna(), 'missing_exposure_or_outcome_effect')
        available = g.index[g.record_status=='retained']
        p_n = len(available)
        assert p_n>0
        g.loc[available,'outcome_P_filter_n'] = p_n
        exclude(g['P.y']<=.05/p_n, 'outcome_P_le_005_over_n')
        exclude(g.outcome_beta_aligned.abs()>100, 'absolute_outcome_beta_gt100')
        exclude(g.outcome_beta_aligned==0, 'zero_outcome_beta')
        available = g.index[g.record_status=='retained']
        before = g.loc[available]
        n = len(before)
        assert n>0 and (before['SE.y']>0).all() and (before['SE.x']>0).all()
        x = before['BETA.x'].to_numpy()/before['SE.y'].to_numpy()
        y = before.outcome_beta_aligned.to_numpy()/before['SE.y'].to_numpy()
        slope = float(x@y/(x@x))
        resid, leverage = y-x*slope, x*x/(x@x)
        cook = np.full(n,np.nan)
        if n>1:
            mse = float(resid@resid/(n-1))
            if mse>0:
                cook = resid**2/mse*leverage/(1-leverage)**2
        g.loc[available,'cook_filter_n'] = n
        g.loc[available,'cook_distance'] = cook
        g.loc[available,'cook_cutoff'] = 4/n
        exclude(g.cook_distance>4/n, 'weighted_no_intercept_Cook_gt4_over_n')
        final = g[g.record_status=='retained']
        x = final['BETA.x'].to_numpy()/final['SE.y'].to_numpy()
        y = final.outcome_beta_aligned.to_numpy()/final['SE.y'].to_numpy()
        beta = float(x@y/(x@x))
        fixed_se = float(1/np.sqrt(x@x))
        q = float(np.sum((y-x*beta)**2)) if len(final)>1 else np.nan
        qp = float(chi2.sf(q,len(final)-1)) if len(final)>1 else np.nan
        random_se = fixed_se*max(1,float(np.sqrt(q/(len(final)-1)))) if len(final)>1 else fixed_se
        selected_se = random_se if qp<.05 else fixed_se
        selected_p = float(2*norm.sf(abs(beta/selected_se)))
        fixed_p = float(2*norm.sf(abs(beta/fixed_se)))
        saved, raw = primary.loc[mid], sensitivity.loc[mid]
        summary = dict(metabolite_id=mid,metabolite=saved.metabolite,
            input_records=len(group),reconstructed_retained=len(final),
            archived_nIV=int(saved.nIV),count_match=len(final)==saved.nIV,
            archived_beta=float(saved.beta),reconstructed_beta=beta,
            absolute_beta_difference=abs(beta-saved.beta),
            archived_primary_SE=float(saved.se),reconstructed_primary_SE=selected_se,
            absolute_SE_difference=abs(selected_se-saved.se),
            archived_primary_P=float(saved.raw_p),reconstructed_primary_P=selected_p,
            absolute_P_difference=abs(selected_p-saved.raw_p),
            selected_archived_model='random_effects_IVW' if qp<.05 else ('single_SNP_Wald' if len(final)==1 else 'fixed_effects_IVW'),
            Q_reconstructed=q,Q_archived=float(saved.Q),Q_P_reconstructed=qp,
            marginal_F_min=float(final.marginal_F.min()),
            adjusted_F_min=float(final.F_original_mean_N_adjustment.min()),
            archived_F_min=float(raw.F_min),
            retained_noncanonical_allele_rows=int((final.allele_label_status=='noncanonical_source_label_requires_confirmation').sum()),
            all_numeric_checks_match=bool(len(final)==saved.nIV and abs(beta-saved.beta)<1e-8 and abs(selected_se-saved.se)<1e-8 and abs(selected_p-saved.raw_p)<1e-8),
            matching_labels_present_before_filters=has_match,
            note='Final label-aligned reconstruction; full strand/frequency validation not established.')
        assert len(final)==raw.n_snp
        if mid not in ['M34732','M37459']:
            assert abs(beta-raw.IVW_fix)<1e-8
            assert abs(fixed_se-raw.SE)<1e-8 and abs(fixed_p-raw.Pval)<1e-8
            if np.isfinite(raw['Heter.est']): assert abs(q-raw['Heter.est'])<1e-7
        assert summary['all_numeric_checks_match'],mid
        assert abs(summary['adjusted_F_min']-summary['archived_F_min'])<1e-8,mid
        summaries.append(summary)
        processed.append(g)

    all_rows = pd.concat(processed).sort_values(['traits','SNP','source_row_1based'])
    retained = all_rows[all_rows.record_status=='retained'].copy()
    excluded = all_rows[all_rows.record_status=='excluded'].copy()
    summary = pd.DataFrame(summaries)
    assert len(retained)==9728 and len(excluded)==880 and len(summary)==485
    assert not retained.duplicated(['traits','SNP']).any()
    assert set(retained.traits)==set(sensitivity.index)
    assert set(retained.source_row_1based)|set(excluded.source_row_1based)==set(d.source_row_1based)
    assert not set(retained.source_row_1based)&set(excluded.source_row_1based)
    # Independent, previously supplied 50-trait record membership and alignment.
    refpath=root/'archive/legacy_supplementary_tables/Supplementary_Table_Significant_MR_Instruments.xlsx'
    ref50_count=None
    if refpath.exists():
        ref=pd.read_excel(refpath,sheet_name='Instrument associations')
        ref50_count=ref['Metabolite ID'].nunique()
        for mid,gr in ref.groupby('Metabolite ID'):
            rec=retained[retained.traits==mid].set_index('SNP')
            assert set(rec.index)==set(gr.SNP),mid
            gr=gr.set_index('SNP').loc[rec.index]
            assert np.allclose(rec.outcome_beta_aligned,gr['Outcome beta (aligned)'],rtol=0,atol=1e-12),mid
        assert ref50_count==50

    retained.to_csv(out/'retained_instruments_485.csv',index=False,float_format='%.17g')
    excluded.to_csv(out/'excluded_records_485.csv',index=False,float_format='%.17g')
    summary.to_csv(out/'verification_485.csv',index=False,float_format='%.17g')
    flagged=retained[retained.allele_label_status=='noncanonical_source_label_requires_confirmation']
    flagged.to_csv(out/'noncanonical_allele_flags.csv',index=False,float_format='%.17g')
    verification=dict(scope='final_primary_estimate_verification',
        rows_input=len(d),retained_records=len(retained),distinct_retained_SNPs=retained.SNP.nunique(),
        excluded_records=len(excluded),available_metabolites=len(summary),planned_metabolites=len(primary),
        missing_original_estimate=primary.index[primary.nIV.isna()].tolist(),
        all485_numeric_match=bool(summary.all_numeric_checks_match.all()),
        all485_archived_adjusted_F_min_match=True,
        reference50_exact_membership_and_aligned_beta_match=ref50_count,
        noncanonical_source_allele_records=len(flagged),noncanonical_source_allele_metabolites=flagged.traits.unique().tolist(),
        excluded_by_stage=excluded.exclusion_stage.value_counts().to_dict(),
        max_absolute_beta_difference=float(summary.absolute_beta_difference.max()),
        max_absolute_primary_SE_difference=float(summary.absolute_SE_difference.max()),
        max_absolute_primary_P_difference=float(summary.absolute_P_difference.max()),
        final_primary_estimates_independently_verified=True,original_LD_clumping_rerun=False,
        full_frequency_based_harmonization_verified=False,
        source_sha256={str(f.relative_to(root)):digest(f) for f in [paired_path,primary_path,sensitivity_path]},
        software=dict(Python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__))
    (out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    print(json.dumps(verification,indent=2))


if __name__=='__main__':
    main()
