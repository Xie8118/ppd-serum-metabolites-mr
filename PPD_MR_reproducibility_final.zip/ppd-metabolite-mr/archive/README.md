# Historical source and result records

This directory preserves earlier source records, intermediate outputs and legacy supplementary workbooks for provenance. These records may differ from the final results. Use ../data/primary_results.tsv and ../data/sensitivity_results.tsv for the final primary and sensitivity estimates, ../output/mvmr_results.tsv for MVMR results, and ../supplementary_tables/Supplementary_Tables.xlsx for the consolidated Tables S1-S30.

sensitivity_results_archived.tsv preserves the sensitivity table that preceded the current supporting isovalerate and ergothioneine analyses. Inputs, settings and outputs for those analyses are supplied in ../allele_direction_correction/.
