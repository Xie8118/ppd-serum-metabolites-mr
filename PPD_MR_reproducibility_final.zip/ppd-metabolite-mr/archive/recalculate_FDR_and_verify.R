args <- commandArgs(trailingOnly=TRUE)
root <- if(length(args)) args[[1]] else "."
stopifnot(as.character(packageVersion("fdrtool"))=="1.2.18")
options(digits=17)
old <- read.delim(file.path(root,"primary_results_archived.tsv"),check.names=FALSE)
x <- read.delim(file.path(root,"primary_results_before_FDR.tsv"),check.names=FALSE)
q_values <- function(p){ok<-is.finite(p);q<-rep(NA_real_,length(p));q[ok]<-fdrtool::fdrtool(p[ok],statistic="pvalue",plot=FALSE)$qval;q}
baseline<-q_values(old$raw_p)
stopifnot(max(abs(baseline-old$FDR_q),na.rm=TRUE)<1e-8)
ret <- read.csv(file.path(root,"retained_instruments_485.csv"),check.names=FALSE)
for(mid in c("M34732","M37459")){
 g<-ret[ret$traits==mid,];w<-1/g$SE.y^2
 b<-sum(w*g$BETA.x*g$outcome_beta_aligned)/sum(w*g$BETA.x^2)
 se<-sqrt(1/sum(w*g$BETA.x^2));p<-2*pnorm(-abs(b/se))
 r<-x[x$metabolite_id==mid,]
 stopifnot(abs(b-r$beta)<1e-12,abs(se-r$se)<1e-12,abs(p-r$raw_p)<1e-12)
}
x$FDR_q<-q_values(x$raw_p)
x$Bonferroni_p<-p.adjust(x$raw_p,method="bonferroni",n=486)
x$FDR5<-x$FDR_q<.05;x$FDR10<-x$FDR_q<.10
write.table(x,file.path(root,"primary_results_corrected.tsv"),sep="\t",quote=FALSE,row.names=FALSE,na="NA")
comparison<-data.frame(metabolite_id=x$metabolite_id,metabolite=x$metabolite,old_P=old$raw_p,new_P=x$raw_p,old_q=old$FDR_q,new_q=x$FDR_q,old_FDR5=old$FDR5,new_FDR5=x$FDR5,old_FDR10=old$FDR10,new_FDR10=x$FDR10)
write.table(comparison,file.path(root,"FDR_comparison_486.tsv"),sep="\t",quote=FALSE,row.names=FALSE,na="NA")
capture.output(sessionInfo(),file=file.path(root,"FDR_sessionInfo.txt"))
print(x[x$metabolite_id%in%c("M34732","M37459","M01573")|x$FDR10%in%TRUE,c("metabolite_id","metabolite","raw_p","FDR_q","FDR5","FDR10")])
cat("Baseline archived q values reproduced; both corrected IVW results independently verified in R.\n")
