# Supplementary pathway analysis

Uses the original 30 HMDB identifiers and complete MetaboAnalyst library membership retrieved on 5 October 2026. These are not verified historical snapshots from the original web session. The union of all library members is the background; identifiers are matched directly after trimming whitespace. All 81 KEGG and 99 SMPDB pathways enter separate fdrtool corrections. All q values are 1. Original MR and original pathway values are retained.

Run `Rscript run_full_pathway_FDR.R .` from this directory. Inputs, complete results, backgrounds, contributors, software versions and fdrtool warnings are included. No external download is needed.
