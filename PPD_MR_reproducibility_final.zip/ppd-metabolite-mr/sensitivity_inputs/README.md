# Sensitivity analysis inputs and estimates

The aligned input contains isovalerate (M34732, five instruments) and ergothioneine (M37459, three instruments). Exposure effects are relative to T; outcome effects are aligned to the same allele. The paired association table contains outcome effects in source orientation before alignment. SNP sets are fixed. Primary IVW uses fixed effects when Cochran Q P>=0.05 and multiplicative random effects otherwise. Complementary estimates and leave-one-out results are supplied.

Run from the extracted root:

```sh
Rscript sensitivity_inputs/run_sensitivity.R pilot sensitivity_inputs
Rscript sensitivity_inputs/run_sensitivity.R full sensitivity_inputs
```

Runtime: R 4.3.3, MendelianRandomization 0.10.0, mr.raps 0.2, data.table 1.17.8. Calls: mr_divw(over.dispersion=TRUE, alpha=0.05, diagnostics=FALSE); mr.raps receives the four beta/SE vectors (defaults in 0.2: over.dispersion=FALSE, loss.function="l2", diagnosis=FALSE, se.method="sandwich"); mr_egger(robust=FALSE, penalized=FALSE, correl=FALSE, distribution="t-dist", alpha=0.05); mr_mbe(weighting="weighted", stderror="delta", iterations=100); mr_median(weighting="weighted", distribution="normal", alpha=0.05, iterations=10000, seed=314159265). RNG seed 20261009 is set before each trait's calls. These settings apply to the supplied two-trait estimates; they do not establish historical settings for other traits.
