# Robust MR software environment

Current supporting environment, inspected 6 October 2026: R 4.3.3, MendelianRandomization 0.10.0 (mr_divw), and mr.raps 0.2. These are the versions selected for subsequent reproducibility checks, not independently verified historical runtime versions for the first submission. Original guanosine D-IVW and MR-RAPS sensitivity estimates have not been refitted. The supplied session record for the supporting isovalerate and ergothioneine analyses reports R 4.3.3, MendelianRandomization 0.10.0, mr.raps 0.2 and data.table 1.17.8; see allele_direction_correction/. This records the current supporting analyses, not the complete historical first-submission environment.

In both inspected installations, mr.raps defaults to over.dispersion=FALSE, loss.function="l2", diagnosis=FALSE, and se.method="sandwich". The default B is 1000 but bootstrap SEs are not selected by default. The analyst-confirmed original helper specifies only the four association vectors. Complete historical runtime/session records remain unavailable.

The analyst-confirmed D-IVW call explicitly sets over.dispersion=TRUE, alpha=0.05 and diagnostics=FALSE. Package inspection and source recovery are not a numerical reproduction test.

Run Rscript R/04_check_robust_environment.R to verify the selected environment without running MR.
