# D-IVW and MR-RAPS source materials

The analyst-confirmed original helper contains mr_divw(..., over.dispersion=TRUE, alpha=0.05, diagnostics=FALSE), and mr.raps(b_exp, b_out, se_exp, se_out) with no additional explicit arguments. The analyst confirmed this helper as the original implementation used for the reported estimates.

The 12-SNP input reference and original saved guanosine output are provided. These two estimators have not been numerically reproduced with the current environment. Current inspected software: R 4.3.3, MendelianRandomization 0.10.0 and mr.raps 0.2; these are not verified original runtime versions. In mr.raps 0.2 the applicable defaults are over.dispersion=FALSE, loss.function="l2", diagnosis=FALSE and se.method="sandwich". See ROBUST_ENVIRONMENT.md and R/04_check_robust_environment.R.

## Analyst confirmation
The analyst confirmed that recovered_candidate_MRfunction.R is the original helper used for the reported sensitivity results. D-IVW uses mr_divw(MRinput, over.dispersion=TRUE, alpha=0.05, diagnostics=FALSE). MR-RAPS passes b_exp, b_out, se_exp and se_out without additional explicit arguments. This confirmation establishes helper identity; it does not recover the complete historical runtime/session record. The original guanosine D-IVW and MR-RAPS estimates are retained; they were not independently rerun in this final verification.
