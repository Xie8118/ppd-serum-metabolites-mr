# Allele-direction correction

M34732 (isovalerate, five instruments) and M37459 (ergothioneine, three instruments) used source exposure effects relative to T. Eight effect-allele labels recorded as TRUE have been corrected to T. data/paired_instruments.csv retains source-oriented outcome effects; it is not an aligned analysis input. aligned_input.tsv contains the outcome effects aligned to exposure T: flip rs1456197, rs4861137 and rs4823691; retain signs for the other five records.

Only these two traits were re-estimated using the fixed original instrument sets; instruments were not reselected and Cook-distance exclusions were not repeated. Primary IVW uses fixed effects because corrected Cochran Q P values exceed 0.05. Corresponding complementary estimates and leave-one-out results were updated. Global primary q values were recalculated across all 485 available P values using fdrtool(..., statistic="pvalue", plot=FALSE)$qval.

Run from the extracted repository root:

```sh
Rscript allele_direction_correction/run_correction.R pilot allele_direction_correction
Rscript allele_direction_correction/run_correction.R full allele_direction_correction
```

Runtime: R 4.3.3, MendelianRandomization 0.10.0, mr.raps 0.2, data.table 1.17.8. Calls follow the analyst-confirmed original helper: mr_divw(over.dispersion=TRUE, alpha=0.05, diagnostics=FALSE); mr.raps receives the four beta/SE vectors (defaults in 0.2: over.dispersion=FALSE, loss.function="l2", diagnosis=FALSE, se.method="sandwich"); mr_egger(robust=FALSE, penalized=FALSE, correl=FALSE, distribution="t-dist", alpha=0.05); mr_mbe(weighting="weighted", stderror="delta", iterations=100); mr_median(weighting="weighted", distribution="normal", alpha=0.05, iterations=10000, seed=314159265). RNG seed20261009 is set before each trait's calls. These settings document the current correction, not a verified historical runtime. Guanosine and the original 30-exposure MVMR estimates were not refitted.
