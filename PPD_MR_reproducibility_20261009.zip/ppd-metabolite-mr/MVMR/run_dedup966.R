library(data.table);library(jsonlite);library(MendelianRandomization);setDTthreads(1)
a=commandArgs(TRUE);out=if(length(a)) a[1] else 'MVMR/generated966';mode=if(length(a)>1) a[2] else 'pilot';base=if(length(a)>2) a[3] else 'MVMR/generated977';dir.create(out,recursive=TRUE,showWarnings=FALSE)
z=fread('MVMR/reconstructed_joint_input.tsv');o=fread(file.path(base,'original_printed.tsv'));ids=o$metabolite_id;k=length(ids)
bcols=paste0('Effect.',ids);scols=paste0('StdErr.',ids)
stopifnot(nrow(z)==977,uniqueN(z$SNP)==966,k==30)
# Check all duplicate groups before choosing representatives. Each row uses one common reference allele.
groups=split(seq_len(nrow(z)),z$SNP);dup=groups[lengths(groups)>1];err=0
for(ii in dup){ref=ii[1];for(j in ii[-1]){
 stopifnot(setequal(c(z$INC_ALLELE.x[j],z$DEC_ALLELE.x[j]),c(z$INC_ALLELE.x[ref],z$DEC_ALLELE.x[ref])))
 sg=ifelse(z$INC_ALLELE.x[j]==z$INC_ALLELE.x[ref],1,-1)
 err=max(err,abs(sg*z$BETA.y[j]-z$BETA.y[ref]),abs(z$SE.y[j]-z$SE.y[ref]),max(abs(sg*as.numeric(z[j,..bcols])-as.numeric(z[ref,..bcols]))),max(abs(as.numeric(z[j,..scols])-as.numeric(z[ref,..scols]))))
}}
stopifnot(err<1e-12)
x=z[!duplicated(SNP)];xlast=z[!duplicated(SNP,fromLast=TRUE)];stopifnot(nrow(x)==966,setequal(x$SNP,z$SNP),!anyDuplicated(x$SNP),requireNamespace('fdrtool',quietly=TRUE))
cr=fread(file.path(base,'source_correlations.tsv'));rho=as.matrix(cr[match(ids,metabolite_id),..ids]);stopifnot(min(eigen(rho,symmetric=TRUE)$values)>0)
if(mode=='pilot'){
 stopifnot(!file.exists(file.path(out,'PILOT.done')))
 write_json(list(original_rows=nrow(z),dedup_rows=nrow(x),unique_snps=uniqueN(x$SNP),duplicate_groups=length(dup),removed_rows=nrow(z)-nrow(x),aligned_duplicate_max_error=err,identical_unique_SNP_set=TRUE,exposures=k,fdrtool_version=as.character(packageVersion('fdrtool'))),file.path(out,'PILOT.json'),auto_unbox=TRUE,pretty=TRUE)
 writeLines('passed',file.path(out,'PILOT.done'));quit(save='no')
}
stopifnot(mode=='full',file.exists(file.path(out,'PILOT.done')),!file.exists(file.path(out,'FULL.done')))
fit=function(d)mr_mvivw(mr_mvinput(bx=as.matrix(d[,..bcols]),bxse=as.matrix(d[,..scols]),by=d$BETA.y,byse=d$SE.y))
f0=readRDS(file.path(base,'verification_fit_NOT_original_saved_object.rds'));f1=fit(x);flast=fit(xlast)
stopifnot(max(abs(f1@Estimate-flast@Estimate))<1e-10,max(abs(f1@StdError-flast@StdError))<1e-10)
saveRDS(f1,file.path(out,'dedup966_sensitivity_fit.rds'));fwrite(x,file.path(out,'dedup966_input.tsv'),sep='\t')
# Existing977 diagnostics used as comparison, not replaced.
old=fread(file.path(base,'diagnostic_summary_30.tsv'));stopifnot(identical(ids,old$metabolite_id))
b=as.numeric(f1@Estimate);se=as.numeric(f1@StdError);p=as.numeric(f1@Pvalue);q=fdrtool::fdrtool(p,statistic='pvalue',plot=FALSE,verbose=FALSE)$qval
bx=as.matrix(x[,..bcols]);sx=as.matrix(x[,..scols]);sy=x$SE.y;y=x$BETA.y;n=nrow(x)
X=bx/sy;Y=y/sy;A=crossprod(X);Ai=solve(A);bm=drop(Ai%*%crossprod(X,Y));stopifnot(max(abs(b-bm))<1e-9,qr(X)$rank==30)
e=Y-drop(X%*%b);Q=sum(e^2);stopifnot(abs(Q-f1@Heter.Stat[1])<1e-7)
G=A/outer(sqrt(diag(A)),sqrt(diag(A)));vif=diag(solve(G));cond=kappa(sweep(X,2,sqrt(diag(A)),'/'),exact=TRUE)
source('MVMR/strength_mvmr_upstream.R')
d=data.frame(SNP=x$SNP,betaYG=y,sebetaYG=sy,bx,sx);names(d)[4:(3+k)]=paste0('betaX',seq_len(k));names(d)[(4+k):(3+2*k)]=paste0('sebetaX',seq_len(k));class(d)=c('mvmr_format','data.frame')
covs=lapply(seq_len(n),function(i)rho*outer(sx[i,],sx[i,]));fa=as.numeric(strength_mvmr(d,covs)[1,]);fz=as.numeric(suppressWarnings(strength_mvmr(d,0))[1,])
Bi=solve(crossprod(bx));C=-sweep(Bi,2,diag(Bi),'/');calc=function(r)vapply(seq_len(k),function(i){v=sweep(sx,2,C[,i],'*');mean(drop(bx%*%C[,i])^2/rowSums((v%*%r)*v))},numeric(1));Ferror=max(abs(calc(rho)-fa),abs(calc(diag(k))-fz));stopifnot(Ferror<1e-8)
v=sweep(sx,2,b,'*');res=y-drop(bx%*%b);qm=c(sum(res^2/(sy^2+rowSums((v%*%rho)*v))),sum(res^2/(sy^2+rowSums(v^2))))
fwrite(data.table(assumption=c('source_phenotype_covariance_approximation','zero_covariance'),modified_Q=qm,nominal_df=n-k-1,nominal_P=pchisq(qm,n-k-1,lower.tail=FALSE)),file.path(out,'modified_Q.tsv'),sep='\t')
XA=X%*%Ai;h=rowSums(XA*X);loo=matrix(b,n,k,byrow=TRUE)-XA*as.numeric(e/(1-h));deltaSE=abs(sweep(sweep(loo,2,b,'-'),2,se,'/'))
jj=unique(c(which.max(h),which.max(deltaSE[,1]),1));influence_error=0
for(j in jj){direct=qr.solve(X[-j,,drop=FALSE],Y[-j]);influence_error=max(influence_error,max(abs(direct-loo[j,])))}
stopifnot(influence_error<1e-8)
c=data.table(metabolite_id=ids,metabolite=o$metabolite,beta977=as.numeric(f0@Estimate),beta966=b,delta_beta=b-as.numeric(f0@Estimate),delta_in_original_SE=(b-as.numeric(f0@Estimate))/as.numeric(f0@StdError),SE977=as.numeric(f0@StdError),SE966=se,SE_ratio=se/as.numeric(f0@StdError),OR977=exp(as.numeric(f0@Estimate)),OR966=exp(b),CI966_lower=exp(f1@CILower),CI966_upper=exp(f1@CIUpper),P977=as.numeric(f0@Pvalue),P966=p,FDR966=q,sign_changed=as.numeric(f0@Estimate)*b<0,nominal_005_changed=(as.numeric(f0@Pvalue)<.05)!=(p<.05),F977_approx=old$conditional_F_phenocov_approx_nominal,F966_approx=fa,F977_zero=old$conditional_F_zero_cov_nominal,F966_zero=fz,VIF977=old$uncentered_design_VIF,VIF966=vif,LOO966_beta_min=apply(loo,2,min),LOO966_beta_max=apply(loo,2,max),LOO966_sign_change_count=colSums(sweep(loo,2,b,'*')<0),LOO966_max_change_SE=apply(deltaSE,2,max))
fwrite(c,file.path(out,'comparison_30.tsv'),sep='\t')
meta=list(scope='deduplication_only_sensitivity_not_primary_replacement',original_rows=977,unique_SNPs=966,removed_rows=11,duplicate_groups=9,original_exposure_count=30,source_unique_SNP_set_unchanged=TRUE,aligned_duplicate_error=err,representative_first_last_beta_error=max(abs(f1@Estimate-flast@Estimate)),n_effect_sign_changes=sum(c$sign_changed),n_nominal_significance_changes=sum(c$nominal_005_changed),max_abs_beta_change=max(abs(c$delta_beta)),max_abs_change_original_SE=max(abs(c$delta_in_original_SE)),SE_ratio_range=range(c$SE_ratio),n_nominal_P_below005=sum(p<.05),n_fdrtool_q_below010=sum(q<.1),fdrtool_q_min=min(q),F966_approx_range=range(fa),F966_zero_range=range(fz),F966_approx_below10=sum(fa<10),F966_zero_below10=sum(fz<10),rank=qr(X)$rank,condition_number_normalized=cond,VIF_range=range(vif),Q977=as.numeric(f0@Heter.Stat[1]),Q966=Q,nominal_Q966_df=n-k,nominal_Q966_P=pchisq(Q,n-k,lower.tail=FALSE),RSE966=f1@RSE,conditional_F_check_error=Ferror,influence_check_error=influence_error,software=list(R=as.character(getRversion()),MendelianRandomization=as.character(packageVersion('MendelianRandomization')),fdrtool=as.character(packageVersion('fdrtool'))),cautions='Dedup removes exact repeated records only. Residual LD not re-clumped or verified;966 unique does not establish966 LD-independent. Conditional F relies on approximate covariance; low values flag weak conditional strength. Postselection bias and original harmonization limitations persist. Existing primary output unchanged.')
write_json(meta,file.path(out,'summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=16)
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'));writeLines('completed',file.path(out,'FULL.done'))
