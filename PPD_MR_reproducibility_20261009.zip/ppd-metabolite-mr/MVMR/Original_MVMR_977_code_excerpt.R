# Historical 977-row model code excerpt.
# Not executed for this supplement; required original GWAS files are not included.
# Relative directories below stand for the original working directories.
	library(data.table)
	library(MendelianRandomization)
	library(progress)
	library(ggplot2)
	
	library(progress)

	setwd("analysis_inputs")
	yx0 = fread(paste("yx_metabolite_New_O15_POSTPART_DEPR_finngenr7_qc_GRCh37_qc.txt",sep=""),header = TRUE)						
	M = c("M01573","M01121","M34214","M20489","M21188","M02137","M32553","M34407",
		"M02342","M36754","M32672","M33969","M01358","M18392","M33228","M15506",
		"M12035","M33178","M01302","M37112","M35628","M01494","M36103","M37104",
		"M33971","M33941","M01301","M33957","M35678","M00553")

	yx1 = yx0[which(yx0$traits%in%M),]
	SNP = as.character(yx1$SNP)
	ind.1 = which(duplicated(SNP)); if(length(ind.1)>0){SNP = SNP[-ind.1]}
	yx.2 = list()
	for(i in 1:length(M)){
		setwd("exposure_gwas")
		M1.data.0 = data.frame(fread(paste(M[i],".metal.pos.txt.gz",sep = ""),header = TRUE,sep="\t",fill=TRUE))
		attach(M1.data.0)
		M1.data = data.frame(MarkerName,Chr,Pos,toupper(Allele1),toupper(Allele2),Effect,StdErr,Effect/StdErr,P.value,TotalSampleSize)
		colnames(M1.data) = c("SNP","CHR","POS","INC_ALLELE","DEC_ALLELE","BETA","SE","Z","P","N")
		M1.data$SNP = as.character(M1.data$SNP)
		yx.1 = M1.data[which(M1.data$SNP%in%SNP),c("SNP","INC_ALLELE","DEC_ALLELE","BETA","SE")]
		colnames(yx.1) = c("MarkerName",paste(c("Allele1","Allele2","Effect","StdErr"),".",M[i],sep=""))
		yx.2[[i]] = yx.1
		print(i)
	}
	tmp = c(1:length(M))
	setwd("analysis_inputs")
	yx0 = fread(paste("yx_metabolite_New_O15_POSTPART_DEPR_finngenr7_qc_GRCh37_qc.txt",sep=""),header = TRUE)						
	yx1 = yx0[which(yx0$traits%in%M),]
	#ind.1 = which(duplicated(as.character(yx1$SNP))); yx1 = yx1[-ind.1,]
	index1=which(toupper(yx1$INC_ALLELE.x)==toupper(yx1$INC_ALLELE.y))
	if (length(index1)<length(yx1$INC_ALLELE.x)){
		yx1$BETA.y[-index1]=yx1$BETA.y[-index1]*(-1)
	}
	for(j in 1:length(tmp)){
		ind.2 = which(duplicated(yx.2[[tmp[j]]]$MarkerName)); if(length(ind.2)>0){yx.2[[tmp[j]]] = yx.2[[tmp[j]]][-ind.2,]}
		yx1 = data.frame(merge(yx1, yx.2[[tmp[j]]], by.x = "SNP", by.y = "MarkerName"))
		index1=which(toupper(yx1$INC_ALLELE.x)==toupper(yx1[,c(paste("Allele1.",M[tmp[j]],sep=""))]))
		if (length(index1)==0){
			yx1[,c(paste("Effect.",M[tmp[j]],sep=""))]=yx1[,c(paste("Effect.",M[tmp[j]],sep=""))]*(-1)
		}else if (length(index1)<length(yx1$INC_ALLELE.x)){
			yx1[-index1,c(paste("Effect.",M[tmp[j]],sep=""))]=yx1[-index1,c(paste("Effect.",M[tmp[j]],sep=""))]*(-1)
		}
		print(dim(yx1)[1])
	}
	yx = na.omit(yx1)
	fit = mr_mvivw(mr_mvinput(bx = as.matrix(yx[,paste("Effect.",M,sep="")]), 
				bxse = as.matrix(yx[,paste("StdErr.",M,sep="")]),
				by = yx$BETA.y, byse = yx$SE.y))


	