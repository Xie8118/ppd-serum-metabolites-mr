library(data.table);library(jsonlite);library(MendelianRandomization);setDTthreads(1)
a=commandArgs(TRUE);out=if(length(a)) a[1] else 'MVMR/generated977';code='MVMR';mode=if(length(a)>1) a[2] else 'pilot';dir.create(out,recursive=TRUE,showWarnings=FALSE)
for(nm in c('original_printed.tsv','source_correlations.tsv')) file.copy(file.path(code,nm),file.path(out,nm),overwrite=FALSE)
src='MVMR/reconstructed_joint_input.tsv'
z=fread(src);orig=fread(file.path(out,'original_printed.tsv'));ids=orig$metabolite_id
bx=as.matrix(z[,paste0('Effect.',ids),with=FALSE]);sx=as.matrix(z[,paste0('StdErr.',ids),with=FALSE]);y=z$BETA.y;sy=z$SE.y
cr=fread(file.path(out,'source_correlations.tsv'));rho=as.matrix(cr[match(ids,metabolite_id),..ids]);n=nrow(bx);k=ncol(bx)
stopifnot(n==977,k==30,uniqueN(z$SNP)==966,all(is.finite(bx)),all(is.finite(sx)),all(sx>0),all(sy>0),all(is.finite(y)),max(abs(rho-t(rho)))<1e-9,all(diag(rho)==1),min(eigen(rho,symmetric=TRUE)$values)>0)
if(mode=='pilot'){
 stopifnot(!file.exists(file.path(out,'PILOT.done')))
 write_json(list(rows=n,unique_snps=uniqueN(z$SNP),exposures=k,valid_positive_SE=TRUE,correlation_eigen_min=min(eigen(rho,symmetric=TRUE)$values),current_R=as.character(getRversion()),current_MendelianRandomization=as.character(packageVersion('MendelianRandomization'))),file.path(out,'PILOT.json'),auto_unbox=TRUE,pretty=TRUE)
 writeLines('validated',file.path(out,'PILOT.done'));quit(save='no')
}
stopifnot(mode=='full',file.exists(file.path(out,'PILOT.done')),!file.exists(file.path(out,'FULL.done')))
# Re-evaluate the original fit solely to verify identity; no re-selection or replacements.
f=mr_mvivw(mr_mvinput(bx=bx,bxse=sx,by=y,byse=sy));saveRDS(f,file.path(out,'verification_fit_NOT_original_saved_object.rds'))
b=as.numeric(f@Estimate);se=as.numeric(f@StdError);pv=as.numeric(f@Pvalue);Q=as.numeric(f@Heter.Stat[1]);df=n-k;rse=as.numeric(f@RSE)
comp=data.table(metabolite_id=ids,metabolite=orig$metabolite,original_beta=orig$beta,verification_beta=b,original_SE=orig$se,verification_SE=se,original_P=orig$p,verification_P=pv,original_lower=orig$lower,verification_lower=f@CILower,original_upper=orig$upper,verification_upper=f@CIUpper)
comp[,all_printed_values_match:=abs(verification_beta-original_beta)<0.00050001 & abs(verification_SE-original_SE)<0.00050001 & abs(verification_P-original_P)<0.00050001 & abs(verification_lower-original_lower)<0.00050001 & abs(verification_upper-original_upper)<0.00050001]
fwrite(comp,file.path(out,'original_output_identity.tsv'),sep='\t')
stopifnot(all(comp$all_printed_values_match),abs(Q-1161.6983)<0.000051,abs(rse-1.108)<0.000501)
# Independent weighted least-squares check.
X=bx/sy;Y=y/sy;A=crossprod(X);Ai=solve(A);manual=drop(Ai%*%crossprod(X,Y));e=Y-drop(X%*%b);stopifnot(qr(X)$rank==k,max(abs(manual-b))<1e-9,abs(sum(e^2)-Q)<1e-7)
# Column-normalized uncentered design geometry fits no-intercept IVW; not phenotype correlations.
dnorm=sqrt(diag(A));G=A/outer(dnorm,dnorm);vif=diag(solve(G));sv=svd(sweep(X,2,dnorm,'/'),nu=0,nv=0)$d
pairs=which(upper.tri(G),arr.ind=TRUE);pt=data.table(exposure1=ids[pairs[,1]],exposure2=ids[pairs[,2]],weighted_uncentered_correlation=G[pairs]);setorder(pt,-weighted_uncentered_correlation)
fwrite(pt,file.path(out,'design_pairwise_geometry.tsv'),sep='\t')
# Conditional strength using source phenotype-covariance approximation, and zero covariance sensitivity.
# Numerical implementation verified against archived official upstream function on the same977 rows.
source(file.path(code,'strength_mvmr_upstream.R'))
dat=data.frame(SNP=paste0(z$SNP,'_row',seq_len(n)),betaYG=y,sebetaYG=sy,bx,sx);names(dat)[4:(3+k)]=paste0('betaX',seq_len(k));names(dat)[(4+k):(3+2*k)]=paste0('sebetaX',seq_len(k));class(dat)=c('mvmr_format','data.frame')
covs=lapply(seq_len(n),function(i)rho*outer(sx[i,],sx[i,]));Fapprox=as.numeric(strength_mvmr(dat,covs)[1,]);Fzero=as.numeric(suppressWarnings(strength_mvmr(dat,0))[1,])
Bi=solve(crossprod(bx));contrast=sweep(Bi,2,diag(Bi),'/' )*(-1)
conditional=function(r){vapply(seq_len(k),function(i){v=sweep(sx,2,contrast[,i],'*');variance=rowSums((v%*%r)*v);stopifnot(all(variance>0));mean(drop(bx%*%contrast[,i])^2/variance)},numeric(1))}
Ferror=max(abs(conditional(rho)-Fapprox),abs(conditional(diag(k))-Fzero));stopifnot(Ferror<1e-8)
# Modified Q, same variance formula as official pleiotropy_mvmr, at verified original-fit coefficients.
v=sweep(sx,2,b,'*');res=y-drop(bx%*%b)
Qmod_approx=sum(res^2/(sy^2+rowSums((v%*%rho)*v)));Qmod_zero=sum(res^2/(sy^2+rowSums(v^2)))
# Source package uses n-k-1 for modified Q; nominal only because repeated rows and covariance approximation.
mod=data.table(assumption=c('source_Pearson_covariance_approximation','zero_covariance'),Q=c(Qmod_approx,Qmod_zero),nominal_df=n-k-1,nominal_P=pchisq(c(Qmod_approx,Qmod_zero),n-k-1,lower.tail=FALSE),calibrated_inference=FALSE)
fwrite(mod,file.path(out,'modified_Q_assumption_checks.tsv'),sep='\t')
# Vectorized exact row deletion plus small-block correction: remove ALL copies of a SNP together.
XA=X%*%Ai;h=rowSums(XA*X);rowbeta=matrix(b,n,k,byrow=TRUE)-XA*as.numeric(e/(1-h));groups=split(seq_len(n),z$SNP);first=vapply(groups,function(ii)ii[1],integer(1));loo=rowbeta[first,,drop=FALSE];rownames(loo)=names(groups)
for(sn in names(groups)[lengths(groups)>1]){
 ii=groups[[sn]];H=X[ii,,drop=FALSE]%*%Ai%*%t(X[ii,,drop=FALSE]);adj=solve(diag(length(ii))-H,e[ii]);loo[sn,]=b-drop(Ai%*%crossprod(X[ii,,drop=FALSE],adj))
}
# Three independent direct deletion solves validate block identity, no mass refitting.
testnames=unique(c(names(groups)[lengths(groups)>1][1],names(groups)[which.max(abs(loo[,1]-b[1]))],names(groups)[which.max(h[first])]))
err=0
for(sn in testnames){ii=groups[[sn]];direct=qr.solve(X[-ii,,drop=FALSE],Y[-ii]);err=max(err,max(abs(direct-loo[sn,])))}
stopifnot(err<1e-8)
delta=sweep(loo,2,b,'-');changeSE=abs(sweep(delta,2,se,'/'));maxidx=apply(changeSE,2,which.max)
summary=data.table(metabolite_id=ids,metabolite=orig$metabolite,original_beta=orig$beta,verified_beta=b,nominal_original_SE=se,uncentered_design_VIF=vif,conditional_F_phenocov_approx_nominal=Fapprox,conditional_F_zero_cov_nominal=Fzero,block_LOO_beta_min=apply(loo,2,min),block_LOO_beta_max=apply(loo,2,max),max_abs_change_in_original_SE=apply(changeSE,2,max),most_influential_SNP=rownames(loo)[maxidx],n_block_deletions_changing_sign=colSums(sweep(loo,2,b,'*')<0))
fwrite(summary,file.path(out,'diagnostic_summary_30.tsv'),sep='\t')
fwrite(data.table(omitted_SNP=rownames(loo),omitted_rows=lengths(groups),loo),file.path(out,'block_deletion_coefficients.tsv'),sep='\t')
# Per-row residual and influence summaries.
fwrite(data.table(SNP=z$SNP,original_row=z$.original_row,leverage=h,Q_contribution=e^2),file.path(out,'row_residual_diagnostics.tsv'),sep='\t')
meta=list(status='computed_and_numerically_checked',model_rows=n,unique_SNPs=length(groups),exposures=k,original_values_match_printed_precision=all(comp$all_printed_values_match),verification_not_new_primary_analysis=TRUE,Q=Q,nominal_Q_df=df,nominal_Q_p=pchisq(Q,df,lower.tail=FALSE),RSE=rse,rank=qr(X)$rank,normalized_design_condition_number=max(sv)/min(sv),design_VIF_range=range(vif),max_abs_weighted_uncentered_pair=max(abs(G[upper.tri(G)])),conditional_F_phenocov_range=range(Fapprox),conditional_F_zero_cov_range=range(Fzero),n_F_below10_phenocov=sum(Fapprox<10),n_F_below10_zero=sum(Fzero<10),conditional_F_numerical_check_error=Ferror,influence_block_identity_error=err,max_leverage=max(h),max_Q_contribution=max(e^2),max_influence_SE=max(changeSE),guanosine=as.list(summary[1]),stearoylglycerol=as.list(summary[5]),duplicate_independence_violation=TRUE,valid_calibrated_conditional_F_claimed=FALSE,source_covariance_approximation='diag(SE) * source phenotype Pearson rho * diag(SE); unequal and SNP-specific sample overlap unavailable',limitation='All977 original rows retained including duplicate SNPs. Nominal F and chi-square statistics not calibrated independent-SNP inference. Weak strength and approximate covariance limit modifiedQ interpretation. No deduplicated fit or693-SNP results used.',R_version=as.character(getRversion()),MendelianRandomization_version=as.character(packageVersion('MendelianRandomization')))
write_json(meta,file.path(out,'summary.json'),auto_unbox=TRUE,pretty=TRUE,digits=16)
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
writeLines('completed',file.path(out,'FULL.done'))
