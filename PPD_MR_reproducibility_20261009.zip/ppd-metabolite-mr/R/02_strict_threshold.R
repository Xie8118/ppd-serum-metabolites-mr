# Count variants before clumping or harmonization; does not run MR.
args <- commandArgs(TRUE)
stopifnot(length(args)==1)
x <- data.table::fread(cmd=paste("gzip -dc",shQuote(args[1])),select=c("MarkerName","P-value"))
p <- x[["P-value"]]
stopifnot(all(is.finite(p)),all(p>=0 & p<=1))
print(data.frame(rows=nrow(x),strict_hits=sum(p<5e-8),minimum_P=min(p),minimum_P_SNP=x$MarkerName[which.min(p)]))
