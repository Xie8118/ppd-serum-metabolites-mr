# Reproduce the FDR columns from the supplied result tables (including the two allele-direction corrections).
# Run from the repository root. No MR estimates are refitted.
# FDR verification: R 4.3.3 / 4.5.3 and fdrtool 1.2.18.
q_values <- function(p) {
  ok <- is.finite(p)
  stopifnot(all(p[ok] >= 0 & p[ok] <= 1))
  q <- rep(NA_real_, length(p))
  q[ok] <- fdrtool::fdrtool(p[ok], statistic="pvalue", plot=FALSE)$qval
  q
}
dir.create("output", showWarnings=FALSE)
for (name in c("primary", "mvmr")) {
  x <- read.delim(paste0("data/", name, "_results.tsv"), check.names=FALSE)
  expected_q <- x$FDR_q
  x$FDR_q <- q_values(x$raw_p)
  stopifnot(identical(is.na(x$FDR_q), is.na(expected_q)))
  stopifnot(max(abs(x$FDR_q - expected_q), na.rm=TRUE) < 1e-8)
  if (name == "primary") {
    x$Bonferroni_p <- p.adjust(x$raw_p, method="bonferroni", n=486)
    x$FDR5 <- x$FDR_q < 0.05
    x$FDR10 <- x$FDR_q < 0.10
  }
  write.table(x, paste0("output/", name, "_results.tsv"), sep="\t", row.names=FALSE, quote=FALSE, na="NA")
}
