# One fixed locus × window/prior/sdY scenario per scheduler array task.
library(data.table);library(jsonlite);library(coloc);setDTthreads(1)
a<-commandArgs(TRUE);w<-'coloc';tid<-as.integer(a[1]);t<-fread(file.path(w,'tasks.tsv'))[task_id==tid];stopifnot(nrow(t)==1)
r<-fread(file.path(w,'regions.tsv'))[region_id==t$region_id];x<-fread(file.path(w,'regions',paste0(t$region_id,'.tsv')))
x<-x[abs(POS-r$POS)<=t$window_kb*1000];nraw<-nrow(x)
for(k in c('EAF','beta_exposure','se_exposure','N_exposure','beta_outcome','se_outcome','outcome_POS'))set(x,j=k,value=as.numeric(x[[k]]))
comp<-function(s)chartr('ACGT','TGCA',s)
x[,direct:=(EA==outcome_EA&OA==outcome_OA)|(comp(EA)==outcome_EA&comp(OA)==outcome_OA)];x[,swapped:=(EA==outcome_OA&OA==outcome_EA)|(comp(EA)==outcome_OA&comp(OA)==outcome_EA)];x[,reason:='retained']
x[!(direct|swapped)|is.na(direct)|is.na(swapped),reason:='incompatible_alleles']
x[paste0(EA,OA)%in%c('AT','TA','CG','GC'),reason:='palindromic_outcome_EAF_unavailable']
x[!is.finite(beta_exposure)|!is.finite(se_exposure)|se_exposure<=0|!is.finite(N_exposure)|N_exposure<=2|!is.finite(EAF)|EAF<=0|EAF>=1,reason:='invalid_exposure']
x[!is.finite(beta_outcome)|!is.finite(se_outcome)|se_outcome<=0,reason:='missing_or_invalid_outcome']
x[is.finite(outcome_POS)&POS!=outcome_POS,reason:='coordinate_mismatch']
# Restore the source-verified C-effect palindrome only after all validity checks.
x[SNP=='rs7137298' & reason=='palindromic_outcome_EAF_unavailable' & EA=='C' & OA=='G' & outcome_EA=='C' & outcome_OA=='G' & abs(EAF-.176)<1e-9 & abs(beta_outcome+.0245339)<1e-9,`:=`(reason='retained',swapped=FALSE)]
z<-x[reason=='retained'];stopifnot(nrow(z)>100,anyDuplicated(z$SNP)==0)
z[,beta_outcome:=beta_outcome*ifelse(swapped,-1,1)]
# coloc's variance-from-SE regression, retaining per-variant N in the main fit.
Ns<-switch(t$sdY_scenario,SNP_specific=z$N_exposure,median=rep(median(z$N_exposure),nrow(z)),min=rep(min(z$N_exposure),nrow(z)),max=rep(max(z$N_exposure),nrow(z)))
oneover<-1/z$se_exposure^2;nvx<-2*Ns*z$EAF*(1-z$EAF);sdy2<-unname(coef(lm(nvx~oneover-1))[1]);stopifnot(is.finite(sdy2),sdy2>0)
D1<-list(beta=z$beta_exposure,varbeta=z$se_exposure^2,type='quant',snp=z$SNP,position=z$POS,sdY=sqrt(sdy2))
D2<-list(beta=z$beta_outcome,varbeta=z$se_outcome^2,type='cc',snp=z$SNP,position=z$POS,N=226707,s=11711/226707)
warn<-character();fit<-withCallingHandlers(coloc.abf(D1,D2,p1=1e-4,p2=1e-4,p12=t$p12),warning=function(w){warn<<-c(warn,conditionMessage(w));invokeRestart('muffleWarning')})
out<-file.path(w,'tasks',sprintf('%03d',tid));dir.create(out,recursive=TRUE,showWarnings=FALSE)
res<-cbind(t,data.table(n_raw=nraw,n_retained=nrow(z),sdY=sqrt(sdy2),N_min=min(z$N_exposure),N_median=median(z$N_exposure),N_max=max(z$N_exposure)),as.data.table(as.list(fit$summary)))
fwrite(res,file.path(out,'summary.tsv'),sep='\t')
if(t$window_kb==500&t$p12==1e-5&t$sdY_scenario=='SNP_specific'){
 fwrite(x,file.path(out,'harmonization.tsv'),sep='\t');fwrite(fit$results,file.path(out,'SNP_posteriors.tsv'),sep='\t')
 fwrite(z,file.path(out,'regional_plot_source.tsv'),sep='\t')
}
write_json(list(status='completed',task_id=tid,region=t$region_id,warnings=unique(warn),exclusions=as.list(table(x$reason)),coloc_version=as.character(packageVersion('coloc'))),file.path(out,'COMPLETE.json'),auto_unbox=TRUE,pretty=TRUE)
