library(MendelianRandomization)
library(mr.raps)
#DD0 ���
#ax0 ��¶
#snp index_exposure(vector)

MR_process = function(ax0,DD0,snp){
	if(length(snp)>1){
		ax = ax0[which(ax0$SNP%in%snp),]
		DD = DD0[which(DD0$SNP%in%snp),]
		}else if(length(snp)==1){
			snp = snp
			ax = ax0
			DD = DD0[which(DD0$SNP%in%snp),]
		}
	yx=merge(ax,DD,by="SNP")
	index1=which(toupper(yx$INC_ALLELE.x)==toupper(yx$INC_ALLELE.y))
	if(length(index1) != 0){
		if (length(index1)<length(yx$INC_ALLELE.x)){
		yx$BETA.y[-index1]=yx$BETA.y[-index1]*(-1)
		}}else if(length(index1) == 0){
		yx$BETA.y=yx$BETA.y*(-1)
		}
	#index = which(yx$P.y<(0.05/length(yx$P.y)))
	m = dim(yx)[1]
	#if (length(index)>0){yx=yx[-index,]}
	n = dim(yx)[1]
	return(list(yx = yx, m = m, n=n))
	}

MR_process_impute = function(ax0,DD0,snp){
		DD = DD0[which(DD0$SNP%in%snp),]
	if(length(snp)>=1){
		if(dim(DD)[1]!=0){
		ind = which(snp%in%DD$SNP)
		rsID_mis = snp[-ind]
		info_miss = ax0[which(ax0$SNP%in%rsID_mis),]
		}else if(dim(DD)[1]==0){
		rsID_mis = snp
		info_miss = ax0[which(ax0$SNP%in%rsID_mis),]
		}
		if(length(rsID_mis)>1){
		n = dim(info_miss)[1]
		for(z in 1:n){
			rsID_miss = info_miss[z,"SNP"]
			chr_miss = info_miss[z,"CHR"]
			pos_miss = as.numeric(info_miss[z,"POS"])
			DD.tmp = DD0[which(DD0$CHR==chr_miss),]
			ranger = DD.tmp$POS-pos_miss
			indd = which(abs(ranger)<500000)
			SNP_impute = DD.tmp[indd,"SNP"]
			ax_tmp = ax0[which(ax0$SNP%in%SNP_impute),]
			ax_impute = ax_tmp[which(ax_tmp$P==min(ax_tmp$P)),]
		snp = c(snp,ax_impute$SNP)
		print(paste("impute_",rsID_miss,"_",z,sep=""))
		}
		ax = ax0[which(ax0$SNP%in%snp),]
		DD = DD0[which(DD0$SNP%in%snp),]		
		}else if(length(rsID_mis)==1){
			rsID_miss = info_miss[z,"SNP"]
			chr_miss = info_miss[z,"CHR"]
			pos_miss = as.numeric(info_miss[1,"POS"])
			DD.tmp = DD0[which(DD0$CHR==chr_miss),]
			ranger = DD.tmp$POS-pos_miss
			indd = which(abs(ranger)<500000)
			SNP_impute = DD.tmp[indd,"SNP"]
			ax_tmp = ax0[which(ax0$SNP%in%SNP_impute),]
			ax_impute = ax_tmp[which(ax_tmp$P==min(ax_tmp$P)),]
			snp = c(snp,ax_impute$SNP)
			print(paste("impute_",rsID_miss,"_",1,sep=""))
			ax = ax0[which(ax0$SNP%in%snp),]
			DD = DD0[which(DD0$SNP%in%snp),]
		}else if(length(rsID_mis)==0){
			snp = snp
			ax = ax0[which(ax0$SNP%in%snp),]
			DD = DD0[which(DD0$SNP%in%snp),]
		}
		yx=merge(ax,DD,by="SNP")
		index1=which(toupper(yx$INC_ALLELE.x)==toupper(yx$INC_ALLELE.y))
		if(length(index1) != 0){
			if (length(index1)<length(yx$INC_ALLELE.x)){
			yx$BETA.y[-index1]=yx$BETA.y[-index1]*(-1)
			}}else if(length(index1) == 0){
			yx$BETA.y=yx$BETA.y*(-1)
			}
	#index = which(yx$P.y<(0.05/length(yx$P.y)))
	m = dim(yx)[1]
	#if (length(index)>0){yx=yx[-index,]}
	n = dim(yx)[1]
	return(list(yx = yx, m = m, n=n))
	}}


MR_sum = function(yx,result="OR"){
	a = NULL;b = NULL;v = NULL;d = NULL;e = NULL;f = NULL;g = NULL;
	MRinput = mr_input(bx = yx$BETA.x ,bxse = yx$SE.x,by = yx$BETA.y,byse = yx$SE.y)
	IVWObject1 = mr_ivw(MRinput,model="fixed")
	IVWObject2 = mr_ivw(MRinput,model="random")
	try({EggerObject <- mr_egger(MRinput,robust = FALSE,penalized = FALSE,correl = FALSE,distribution = "t-dist",alpha = 0.05)})
	if(dim(yx)[1]>2){MedianObject <- mr_mbe(MRinput,weighting="weighted", stderror="delta", iterations=100)}else{MedianObject = NULL}
	try({weighted_MedianObject <- mr_median(MRinput, weighting = "weighted",distribution = "normal", alpha = 0.05, iterations = 10000,seed = 314159265)})
	try({DIVWObject <- mr_divw(MRinput, over.dispersion = TRUE, alpha = 0.05, diagnostics = FALSE)})
	#try({LassoObject <- mr_lasso(MRinput,distribution = "normal", alpha = 0.05, lambda = numeric(0))})
	try({yx1 = yx[,c("BETA.x","SE.x","BETA.y","SE.y")];
		MRRAP_Object <- mr.raps(b_exp = yx1$BETA.x, b_out = yx1$BETA.y, se_exp = yx1$SE.x, se_out = yx1$SE.y);
		#colnames(yx1) = c("beta.exposure","se.exposure","beta.outcome","se.outcome"); MRRAP_Object <- mr.raps(yx1);
		Z = MRRAP_Object$beta.hat/MRRAP_Object$beta.se})
	try({
	Res1 = c(IVWObject1$Estimate,IVWObject1$StdError,IVWObject1$CILower,IVWObject1$CIUpper,IVWObject1$Pvalue,IVWObject1$Heter.Stat)
	Res2 = c(IVWObject2$Estimate,IVWObject2$StdError,IVWObject2$CILower,IVWObject2$CIUpper,IVWObject2$Pvalue,IVWObject2$Heter.Stat)
	Res3 = c(EggerObject$Estimate,EggerObject$StdError.Est,EggerObject$CILower.Est,EggerObject$CIUpper.Est,EggerObject$Pvalue.Est,EggerObject$Heter.Stat)
	Res4 = c(EggerObject$Intercept,EggerObject$StdError.Int,EggerObject$CILower.Int,EggerObject$CIUpper.Int,EggerObject$Pvalue.Int)
	Res5 = c(MedianObject$Estimate,MedianObject$StdError,MedianObject$CILower,MedianObject$CIUpper,MedianObject$Pvalue)
	Res6 = c(weighted_MedianObject$Estimate,weighted_MedianObject$StdError,weighted_MedianObject$CILower,weighted_MedianObject$CIUpper,weighted_MedianObject$Pvalue)
	Res7 = c(DIVWObject$Estimate,DIVWObject$StdError,DIVWObject$CILower,DIVWObject$CIUpper,DIVWObject$Pvalue)
	#Res8 = c(LassoObject$Estimate,LassoObject$StdError,LassoObject$CILower,LassoObject$CIUpper,LassoObject$Pvalue)
	Res9 = c(MRRAP_Object$beta.hat,MRRAP_Object$beta.se,MRRAP_Object$beta.hat-1.96*MRRAP_Object$beta.se,MRRAP_Object$beta.hat+1.96*MRRAP_Object$beta.se,2*(1-pnorm(abs(Z))))
	if(result == "OR"){
		temp_1 = c(Res1[1:2],exp(Res1[c(1,3:4)]),Res1[5:7]);
		if(is.null(Res2)){temp_2 = rep(NA,8)} else {temp_2 = c(Res2[1:2],exp(Res2[c(1,3:4)]),Res2[5:7])} ;
		if(is.null(Res3)){temp_3 = rep(NA,8)} else {temp_3 = c(Res3[1:2],exp(Res3[c(1,3:4)]),Res3[5:7])};
		if(is.null(Res4)){temp_4 = rep(NA,8)} else {temp_4 = c(Res4[1:2],Res4[c(1,3:4)],Res4[5],NA,NA)} ;
		if(is.null(Res5)){temp_5 = rep(NA,8)} else {temp_5 = c(Res5[1:2],exp(Res5[c(1,3:4)]),Res5[5],NA,NA)};
		if(is.null(Res6)){temp_6 = rep(NA,8)} else {temp_6 = c(Res6[1:2],exp(Res6[c(1,3:4)]),Res6[5],NA,NA)};
		if(is.null(Res7)){temp_7 = rep(NA,8)} else {temp_7 = c(Res7[1:2],exp(Res7[c(1,3:4)]),Res7[5],NA,NA)}
		#if(is.null(Res8)){temp_8 = rep(NA,8)} else {temp_8 = c(Res8[1:2],exp(Res8[c(1,3:4)]),Res8[5],NA,NA)}
		if(is.null(Res9)){temp_9 = rep(NA,8)} else {temp_9 = c(Res9[1:2],exp(Res9[c(1,3:4)]),Res9[5],NA,NA)}
		res = rbind(temp_1,temp_2,temp_3,temp_4,temp_5,temp_6,temp_7,temp_9)
		rownames(res) = c("IVW_fix","IVW_random","Egger_slope","Egger_intercept","weighted_mode","weighted_Median","DIVW","MR-RAPS")
		colnames(res) = c("BETA","SE","OR","Down","Up","Pval","Heter.est","Heter.Pval")
	}else if(result == "BETA"){
		temp_1 = c(Res1[1:4],Res1[5:7]);
		if(is.null(Res2)){temp_2 = rep(NA,7)} else {temp_2 = c(Res2[1:4],Res2[5:7])};
		if(is.null(Res3)){temp_3 = rep(NA,7)} else {temp_3 = c(Res3[1:4],Res3[5:7])};
		if(is.null(Res4)){temp_4 = rep(NA,7)} else {temp_4 = c(Res4[1:4],Res4[5],NA,NA)};
		if(is.null(Res5)){temp_5 = rep(NA,7)} else {temp_5 = c(Res5[1:4],Res5[5],NA,NA)};
		if(is.null(Res6)){temp_6 = rep(NA,7)} else {temp_6 = c(Res6[1:4],Res6[5],NA,NA)};
		if(is.null(Res7)){temp_7 = rep(NA,7)} else {temp_7 = c(Res7[1:4],Res7[5],NA,NA)};
		#if(is.null(Res8)){temp_8 = rep(NA,7)} else {temp_8 = c(Res8[1:4],Res8[5],NA,NA)};
		if(is.null(Res9)){temp_9 = rep(NA,7)} else {temp_9 = c(Res9[1:4],Res9[5],NA,NA)};
		res = rbind(temp_1,temp_2,temp_3,temp_4,temp_5,temp_6,temp_7,temp_9)
		rownames(res) = c("IVW_fix","IVW_random","Egger_slope","Egger_intercept","weighted_mode","weighted_Median","DIVW","MR-RAPS")
		colnames(res) = c("BETA","SE","Down","Up","Pval","Heter.est","Heter.Pval")
		}
	return(list(IVW_fix = temp_1, IVW_random = temp_2, Egger_est = temp_3, Egger_int =temp_4, weighted_Median = temp_5, simple_Median = temp_6, result = res))
	})
}






