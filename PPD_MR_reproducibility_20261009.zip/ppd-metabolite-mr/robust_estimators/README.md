# D-IVW and MR-RAPS source materials

The recovered candidate helper contains mr_divw(..., over.dispersion=TRUE, alpha=0.05, diagnostics=FALSE), and mr.raps(b_exp, b_out, se_exp, se_out) with no additional explicit arguments. The original analysis script referenced an external helper whose exact identity with this recovered copy is not independently verified.

The 12-SNP input reference and original saved guanosine output are provided. The original guanosine estimates from these two estimators have not been numerically reproduced with the current environment. The same helper was used for the documented current allele-direction corrections to M34732 and M37459. Current inspected software: R 4.3.3, MendelianRandomization 0.10.0 and mr.raps 0.2; these are not verified original runtime versions. In mr.raps 0.2 the applicable defaults are over.dispersion=FALSE, loss.function="l2", diagnosis=FALSE and se.method="sandwich". See ROBUST_ENVIRONMENT.md and R/04_check_robust_environment.R.
