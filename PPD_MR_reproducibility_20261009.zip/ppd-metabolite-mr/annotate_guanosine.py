"""Functional annotation and published association lookup; no instrument deletion."""
import csv,json,re,zipfile,io,subprocess
from pathlib import Path
import argparse
ap=argparse.ArgumentParser();ap.add_argument('--references',required=True);ap.add_argument('--eur-prefix',required=True);ap.add_argument('--plink',default='plink');args=ap.parse_args()
ref=Path(args.references);out=Path('annotation_output');out.mkdir(exist_ok=True)
ids=['rs7137298','rs11141909','rs12052900','rs1577941','rs16887484','rs16933423','rs17224277','rs2257243','rs2846365','rs4661299','rs7438272','rs9353315'];(out/'leads.txt').write_text('\n'.join(ids)+'\n')
cmd=[args.plink,'--bfile',args.eur_prefix,'--r2','--ld-snp-list',str(out/'leads.txt'),'--ld-window-kb','500','--ld-window','999999','--ld-window-r2','0.8','--out',str(out/'proxy_LD'),'--threads','1','--memory','1800']
subprocess.run(cmd,check=True,stdout=(out/'plink.stdout').open('w'),stderr=subprocess.STDOUT)
with (out/'proxy_LD.ld').open() as f:
 header=f.readline().split();ld=[dict(zip(header,l.split())) for l in f]
lookup={s:[(s,1.0)] for s in ids}
for r in ld:
 a,b=r['SNP_A'],r['SNP_B'];v=float(r['R2'])
 if a in ids and (a,v) not in lookup.get(b,[]):lookup.setdefault(b,[]).append((a,v))
 if b in ids and (b,v) not in lookup.get(a,[]):lookup.setdefault(a,[]).append((b,v))
def save(name,rows,fields=None):
 with (out/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]),delimiter='\t');w.writeheader();w.writerows(rows)
import urllib.request,hashlib
vp=ref/'Ensembl'/'rs7137298.json'
if not vp.exists():
 url='https://grch37.rest.ensembl.org/vep/human/id/rs7137298?canonical=1&content-type=application/json'
 with urllib.request.urlopen(url,timeout=60) as response: payload=response.read()
 assert isinstance(json.loads(payload),list)
 vp.write_bytes(payload)
 (out/'single_variant_reference.json').write_text(json.dumps({'url':url,'sha256':hashlib.sha256(payload).hexdigest()}))
functional=[]
for s in ids:
 p=ref/'Ensembl'/f'{s}.json'
 if not p.exists():functional.append(dict(SNP=s,status='unavailable',consequence='',genes='',location='',assembly=''));continue
 a=json.loads(p.read_text())[0];tx=a.get('transcript_consequences',[]);functional.append(dict(SNP=s,status='annotated',consequence=a.get('most_severe_consequence',''),genes=';'.join(sorted({t.get('gene_symbol',t.get('gene_id','')) for t in tx})),location=f"{a.get('seq_region_name')}:{a.get('start')}",assembly=a.get('assembly_name','')))
save('Guanosine_functional_annotation.tsv',functional)
groups={'BMI_obesity':r'body mass|bmi|obes|waist|adiposity','smoking':r'smok|tobacco|cigarette|nicotine','alcohol':r'alcohol|drinking|drink consumption','education_SES':r'education|educational|income|deprivation|socioeconomic','pregnancy_birth':r'pregnan|gestation|childbirth|parity|live birth|age at first birth|number of children','psychiatric':r'depress|psychiatr|bipolar|schizophrenia|anxiety|neuroticism'}
hits=[];scanned=0
with zipfile.ZipFile(ref/'GWAS_Catalog/associations.zip') as z:
 for name in z.namelist():
  if name.endswith('/') or name.startswith('__MACOSX'):continue
  with z.open(name) as f:
   r=csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig'),delimiter='\t')
   for row in r:
    scanned+=1;snps=set(re.findall(r'rs\d+',row.get('SNPS','')+' '+row.get('STRONGEST SNP-RISK ALLELE','')))&set(lookup)
    if not snps:continue
    try:p=float(row['P-VALUE'])
    except (ValueError,KeyError):continue
    if p>=5e-8:continue
    trait=row.get('DISEASE/TRAIT','');search=trait+' '+row.get('MAPPED_TRAIT','');cats=';'.join(k for k,v in groups.items() if re.search(v,search,re.I)) or 'other_published_trait'
    for snp in sorted(snps):
     for lead,r2 in lookup[snp]:hits.append(dict(lead_SNP=lead,associated_SNP=snp,proxy_r2=r2,trait=trait,mapped_trait=row.get('MAPPED_TRAIT',''),category=cats,p_value=p,study=row.get('STUDY ACCESSION',''),PubMed=row.get('PUBMEDID',''),mapped_gene=row.get('MAPPED_GENE',''),source='GWAS Catalog curated published associations'))
fields=['lead_SNP','associated_SNP','proxy_r2','trait','mapped_trait','category','p_value','study','PubMed','mapped_gene','source'];save('Guanosine_published_associations.tsv',hits,fields)
save('Guanosine_LD_proxies.tsv',[dict(lead_SNP=l,proxy_SNP=s,r2=r) for s,ls in lookup.items() for l,r in ls])
(out/'VALIDATION.json').write_text(json.dumps(dict(status='completed',n_leads=len(ids),n_functional=len(functional),n_proxy_variants=len(lookup),catalog_rows_scanned=scanned,matched_associations=len(hits),scope='Curated published catalog associations; not all-GWAS summary-statistic search',no_instrument_deletion=True),indent=2))
print((out/'VALIDATION.json').read_text())
