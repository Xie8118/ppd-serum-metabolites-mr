args<-commandArgs(TRUE);setwd(args[1]);x<-read.delim('original_HMDB_selected30.tsv');sets<-read.delim('Pathway_membership.tsv');selected<-unique(trimws(x$HMDB_trimmed));stopifnot(length(selected)==30)
all<-list();sm<-list();warns<-list();qfun<-function(p,label){w<-character();q<-withCallingHandlers(fdrtool::fdrtool(p,statistic='pvalue',plot=FALSE,verbose=FALSE)$qval,warning=function(e){w<<-c(w,conditionMessage(e));invokeRestart('muffleWarning')});warns[[label]]<<-w;q}
for(lib in c('kegg','smpdb')){
 ss<-sets[sets$library==lib,];members<-lapply(strsplit(ss$compound_ids,';',fixed=TRUE),unique);bg<-unique(unlist(members));sel<-intersect(selected,bg);N<-length(bg);n<-length(sel)
 out<-do.call(rbind,lapply(seq_along(members),function(i){m<-members[[i]];h<-intersect(sel,m);K<-length(m);k<-length(h);data.frame(library=lib,pathway_id=ss$pathway_id[i],pathway=ss$pathway[i],N=N,n=n,K=K,hits=k,expected=n*K/N,raw_P=phyper(k-1,K,N-K,n,lower.tail=FALSE),contributors=paste(h,collapse=';'))}))
 out$fdrtool_q<-qfun(out$raw_P,lib);all[[lib]]<-out
 write.table(data.frame(compound_id=bg,selected=bg%in%sel),paste0(lib,'_background.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
 sm[[lib]]<-data.frame(library=lib,N=N,n=n,tested=nrow(out),hit_pathways=sum(out$hits>0),P05=sum(out$raw_P<.05),q05=sum(out$fdrtool_q<.05),q10=sum(out$fdrtool_q<.1),minimum_P=min(out$raw_P),minimum_q=min(out$fdrtool_q))
}
r<-do.call(rbind,all);summary<-do.call(rbind,sm);write.table(r,'full_current_library_FDR.tsv',sep='\t',row.names=FALSE,quote=FALSE);write.table(summary,'summary.tsv',sep='\t',row.names=FALSE,quote=FALSE)
capture.output(warns,file="warnings.txt");capture.output(sessionInfo(),file="sessionInfo.txt");print(summary)
